import streamlit as st
import sqlite3
import hashlib
import os
import datetime

# Database setup
def init_db():
    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS users (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        username TEXT UNIQUE NOT NULL,
                        password TEXT NOT NULL,
                        created_at TEXT NOT NULL,
                        updated_at TEXT,
                        deleted_flag INTEGER DEFAULT 0)''')
    conn.commit()
    conn.close()

# Hash password
def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

# Authenticate user (ignores deleted accounts)
def authenticate_user(username, password):
    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()
    cursor.execute("SELECT password FROM users WHERE username = ? AND deleted_flag = 0", (username,))
    user = cursor.fetchone()
    conn.close()
    return user and user[0] == hash_password(password)

# Register user (Reactivate if deleted)
def register_user(username, password):
    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()
    try:
        created_at = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        cursor.execute("SELECT deleted_flag FROM users WHERE username = ?", (username,))
        existing_user = cursor.fetchone()
        
        if existing_user:
            if existing_user[0] == 1:  # If deleted, reactivate account
                cursor.execute("UPDATE users SET password = ?, deleted_flag = 0, updated_at = ? WHERE username = ?", 
                               (hash_password(password), created_at, username))
                conn.commit()
                conn.close()
                return True
            else:
                conn.close()
                return False  # Username already exists and is active
        
        cursor.execute("INSERT INTO users (username, password, created_at) VALUES (?, ?, ?)", 
                       (username, hash_password(password), created_at))
        conn.commit()
        conn.close()
        return True
    except sqlite3.IntegrityError:
        conn.close()
        return False

# Update Password
def update_password(username, new_password):
    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()
    updated_at = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cursor.execute("UPDATE users SET password = ?, updated_at = ? WHERE username = ?", 
                   (hash_password(new_password), updated_at, username))
    conn.commit()
    conn.close()

# Soft Delete User Account (Marks as deleted)
def delete_account(username):
    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()
    updated_at = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cursor.execute("UPDATE users SET deleted_flag = 1, updated_at = ? WHERE username = ?", (updated_at, username))
    conn.commit()
    conn.close()

# Login UI
def login_ui():
    st.title("🔐 Login / Register")
    username = st.text_input("Username")
    password = st.text_input("Password", type="password")

    if st.button("Login"):
        if authenticate_user(username, password):
            st.session_state.logged_in = True
            st.session_state.username = username
            st.success(f"Welcome back, {username}!")
            st.rerun()
        else:
            st.error("Invalid username or password.")

    if st.button("Register"):
        if register_user(username, password):
            st.success("Registered successfully! Please log in.")
        else:
            st.error("Username already exists.")

# Main function
def main():
    init_db()  # Ensure the database is initialized
    
    if 'logged_in' not in st.session_state:
        st.session_state.logged_in = False

    if not st.session_state.logged_in:
        login_ui()
        return

    # Initialize session state for stock and dates
    if 'stock_symbol' not in st.session_state:
        st.session_state.stock_symbol = "GOOG"  # Default stock symbol
    if 'start_date' not in st.session_state:
        st.session_state.start_date = "2022-01-01"  # Default start date
    if 'end_date' not in st.session_state:
        st.session_state.end_date = "2023-01-01"  # Default end date

    # Sidebar Navigation
    st.sidebar.title(f"👤 Welcome, {st.session_state.username}")
    page = st.sidebar.radio("📌 Navigation", ["🏠 Home", "📊 Stock Data", "📈 Moving Averages", "🔮 Prediction", "⚠️ Delete Account"])

    if page == "🏠 Home":
        import home
        home.home()
    elif page == "📊 Stock Data":
        import stock_data
        stock_data.stock_data_page()
    elif page == "📈 Moving Averages":
        import moving_average
        moving_average.moving_average_page()
    elif page == "🔮 Prediction":
        import prediction
        prediction.prediction_page()
    elif page == "⚠️ Delete Account":
        st.warning("This will delete your account permanently.")
        
        # Update Password Feature
        st.subheader("🔑 Update Password")
        new_password = st.text_input("Enter New Password", type="password")
        confirm_password = st.text_input("Confirm New Password", type="password")
        
        if st.button("Update Password"):
            if new_password and new_password == confirm_password:
                update_password(st.session_state.username, new_password)
                st.success("Password updated successfully!")
            else:
                st.error("Passwords do not match. Try again.")

        # Delete Account Feature
        st.subheader("❌ Delete Account")
        if st.button("Delete My Account"):
            delete_account(st.session_state.username)
            st.session_state.logged_in = False
            st.session_state.username = None
            st.success("Your account has been deleted.")
            st.rerun()

    # Logout button in the sidebar
    st.sidebar.markdown("---")  # Adds a separator
    if st.sidebar.button("🚪 Logout", help="Click to logout"):
        st.session_state.logged_in = False
        st.session_state.username = None
        st.rerun()

if __name__ == '__main__':
    main()
