import streamlit as st
import numpy as np
import yfinance as yf
import os
import pandas as pd
import plotly.express as px  # ✅ Import plotly.express for plotting
from keras.models import load_model
from sklearn.preprocessing import MinMaxScaler

# File Paths
BASE_DIR = os.path.dirname(os.path.abspath(__file__))  # Current script directory
MODEL_FILE = os.path.join(BASE_DIR, 'Stock Predictions Model_1.keras')  # Directly reference users.json

# File Paths
# S_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'S')
# MODEL_FILE = 'C:/Renu/Repos/a/a/S/Stock Predictions Model_1.keras'
#MODEL_FILE = os.path.join(S_DIR, 'Stock_Predictions_Model_1.keras')

def prediction_page():
    st.title("🔮 Stock Price Prediction")

    if not os.path.exists(MODEL_FILE):
        st.error("Model file not found.")
        return

    model = load_model(MODEL_FILE)

    stock = st.session_state.stock_symbol
    start_date = st.session_state.start_date
    end_date = st.session_state.end_date

    try:
        # Fetch historical data
        data = yf.download(stock, start_date, end_date)
        if data.empty:
            st.error(f"No data found for {stock}. Try another stock or date range.")
            return
        
        # Scale the data
        scaler = MinMaxScaler(feature_range=(0, 1))
        scaled_data = scaler.fit_transform(data[['Close']])

        # Prepare last 100 days of data for prediction
        last_100_days = scaled_data[-100:]

        # Predict next 3 days
        predictions = []
        for _ in range(3):
            x_input = np.array(last_100_days).reshape(1, 100, 1)
            y_pred = model.predict(x_input)[0][0]
            predictions.append(y_pred)
            last_100_days = np.append(last_100_days[1:], [[y_pred]], axis=0)

        # Convert predictions back to original price scale
        predictions = np.array(predictions) * (1 / scaler.scale_[0])

        # Generate future dates dynamically
        last_date = data.index[-1]  # Last date in the dataset
        future_dates = pd.date_range(start=last_date + pd.Timedelta(days=1), periods=3)  # Next 3 days

        # Create DataFrame for display
        prediction_df = pd.DataFrame({'Date': future_dates, 'Predicted Price (USD)': predictions})
        st.subheader(f"Predicted Prices for {stock} (Next 3 Days)")
        st.write(prediction_df)  # Display as a table

        # Plot the predicted data
        st.subheader("📈 Future Price Trend")
        fig = px.line(title=f"Predicted Prices for {stock} (Next 3 Days)")
        fig.add_scatter(x=future_dates, y=predictions, mode='lines+markers', name='Predicted Price')
        st.plotly_chart(fig)

    except Exception as e:
        st.error(f"Error: {e}")

if __name__ == '__main__':
    prediction_page()
