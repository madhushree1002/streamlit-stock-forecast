import streamlit as st
import yfinance as yf
import plotly.express as px

def moving_average_page():
    st.title("📈 Moving Averages")
    
    stock = st.session_state.stock_symbol
    start_date = st.session_state.start_date
    end_date = st.session_state.end_date
    st.write(start_date)
    try:
        # Download stock data
        data = yf.download(stock, start_date, end_date)

        # Compute moving averages
        ma_50 = data['Close'].rolling(50).mean()
        ma_100 = data['Close'].rolling(100).mean()

        # Ensure data is 1D by calling .values.flatten()
        fig = px.line(title=f"Price with Moving Averages for {stock}")
        fig.add_scatter(x=data.index, y=data['Close'].values.flatten(), mode='lines', name='Stock Price')
        fig.add_scatter(x=data.index, y=ma_50.values.flatten(), mode='lines', name='MA50')
        fig.add_scatter(x=data.index, y=ma_100.values.flatten(), mode='lines', name='MA100')

        # Display the chart
        st.plotly_chart(fig)

    except Exception as e:               
        st.error(f"Error fetching data: {e}")

if __name__ == '__main__':
    moving_average_page()
