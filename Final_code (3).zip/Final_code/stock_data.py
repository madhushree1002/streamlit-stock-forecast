import streamlit as st
import yfinance as yf
import plotly.graph_objects as go
import pandas as pd

def stock_data_page():
    st.title("📊 Stock Data")

    # Get user input for stock and date range
    # stock = st.text_input('Enter Stock Symbol', st.session_state.get("stock_symbol", "AAPL"))
    # start_date = st.text_input('Stock Start Date (YYYY-MM-DD)', st.session_state.get("start_date", "2023-01-01"))
    # end_date = st.text_input('Stock End Date (YYYY-MM-DD)', st.session_state.get("end_date", "2023-12-31"))
    # Dynamic update: sync inputs with session state
        # Get user input for stock and date range
    stock = st.text_input('Enter Stock Symbol', st.session_state.get("stock_symbol", "AAPL"))
    start_date = st.text_input('Stock Start Date (YYYY-MM-DD)', st.session_state.get("start_date", "2023-01-01"))
    end_date = st.text_input('Stock End Date (YYYY-MM-DD)', st.session_state.get("end_date", "2023-12-31"))

    # Update session state
    st.session_state.stock_symbol = stock
    st.session_state.start_date = start_date
    st.session_state.end_date = end_date

    # Fetch stock data
    try:
        data = yf.download(stock, start=start_date, end=end_date)

        if data.empty:
            st.error(f"❌ No data found for {stock}. Try another stock or date range.")
            return
        
        st.write("🔍 Debug: First 5 rows of `data1` after cleaning:")
        st.write(data)

        # Flatten MultiIndex columns if necessary
        if isinstance(data.columns, pd.MultiIndex):
            data.columns = ['_'.join(col).strip() for col in data.columns.values]

        # Ensure required columns are present
        required_columns = ["Open", "High", "Low", "Close"]
        data.rename(columns=lambda x: x.split('_')[0] if '_' in x else x, inplace=True)

        # Check for missing columns
        missing_columns = [col for col in required_columns if col not in data.columns]
        if missing_columns:
            st.error(f"❌ Missing columns: {missing_columns}")
            return

        # Reset index and format date column
        data.reset_index(inplace=True)
        data["Date"] = data["Date"].dt.strftime('%Y-%m-%d')

        # Create and display candlestick chart
        fig = go.Figure(data=[go.Candlestick(
            x=data["Date"],
            open=data["Open"],
            high=data["High"],
            low=data["Low"],
            close=data["Close"],
            name="Candlestick Chart"
        )])

        fig.update_layout(
            title=f"{stock} Candlestick Chart",
            xaxis_title="Date",
            yaxis_title="Stock Price ($)",
            xaxis_rangeslider_visible=True,
            autosize=True,
            height=600,  # Adjust height
            width=1000,  # Adjust width
            xaxis=dict(type="category"),  # Ensures proper date formatting
            template="plotly_dark"
        )

        # 📌 Display the chart inside Streamlit, making it responsive
        st.plotly_chart(fig, use_container_width=True)

    except Exception as e:
        st.error(f"❌ Error fetching data: {e}")

if __name__ == '__main__':
    stock_data_page()
