import sqlite3

# Connect to (or create) a database
conn = sqlite3.connect("users.db")

# Create a cursor
cursor = conn.cursor()

# Execute an SQL command
cursor.execute("SELECT sqlite_version();")

# Fetch and print results
print(cursor.fetchone())

# Close connection
conn.close()


# Connect to the database (or create if it doesn't exist)
conn = sqlite3.connect("users.db")

# Create a cursor object to interact with the database
cursor = conn.cursor()

# Execute a query to fetch all records from the users table
cursor.execute("SELECT * FROM users")

# Fetch all rows
rows = cursor.fetchall()

# Get column names
column_names = [description[0] for description in cursor.description]

# Print column names
print(" | ".join(column_names))
print("-" * 50)

# Print all records
for row in rows:
    print(" | ".join(map(str, row)))

# Close the connection
conn.close()


