import streamlit as st

def home():
    st.title("📈 Stock Market Predictor")
    st.write("""
        Welcome to the **Stock Market Predictor**!  
        - 📊 View historical stock data
        - 📈 Analyze moving averages
        - 🔮 Predict future stock prices
        
        Use the sidebar to navigate!
    """)

if __name__ == '__main__':
    home()
