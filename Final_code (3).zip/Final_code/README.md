# Stock Market Predictor Application

This application predicts stock market prices using a Keras model and displays the results using Streamlit.

## Prerequisites

* Python 3.6 or later
* pip (Python package installer)

## Setup Instructions (Windows)

1.  **Create a Virtual Environment:**

    * Open a command prompt or PowerShell window.
    * Navigate to the directory containing your `app.py` and `requirements.txt` files.
    * Run the following command to create a virtual environment named `venv`:

        ```bash
        python -m venv venv
        ```

2.  **Activate the Virtual Environment:**

    * Run the following command to activate the virtual environment:

        ```bash
        venv\Scripts\activate
        ```

    * Your command prompt should now show `(venv)` at the beginning, indicating the virtual environment is active.

3.  **Install Dependencies:**

    * Install the required Python packages from the `requirements.txt` file:

        ```bash
        pip install -r requirements.txt
        ```

4.  **Run the Streamlit Application:**

    * Start the Streamlit application by running:

        ```bash
        streamlit run app.py
        ```

    * Streamlit will open your default web browser and display the application.

## Usage

1.  **Login/Register:**
    * If you are a new user, register an account.
    * If you have an existing account, log in.

2.  **Stock Prediction:**
    * Enter the stock symbol (e.g., GOOG, AAPL).
    * Enter the start and end dates for the stock data (YYYY-MM-DD format).
    * The application will display the stock data, moving average charts, and predictions.

3.  **Logout:**
    * Click the "Logout" button in the sidebar to log out.

## Notes

* Ensure that the `users.json` and `Stock Predictions Model_1.keras` files are located in the `S` directory.
* The `requirements.txt` file should contain all the necessary Python packages.
* If you encounter any issues with the model file not being found, double check the path in the app.py file.